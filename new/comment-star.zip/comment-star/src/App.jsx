
import './App.css'
import Comment from './components/Comment'

function App() {
  return (
    <main>
        <Comment />
    </main>
  )
}

export default App
